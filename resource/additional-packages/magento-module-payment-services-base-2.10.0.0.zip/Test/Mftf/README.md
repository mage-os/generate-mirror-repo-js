# PaymentServicesBase Module Functional Tests

The Functional tests for **Magento_PaymentServicesBase** module
