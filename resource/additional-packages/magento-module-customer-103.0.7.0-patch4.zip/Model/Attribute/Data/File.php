<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Customer Attribute File Data Model
 */
namespace Magento\Customer\Model\Attribute\Data;

class File extends \Magento\Eav\Model\Attribute\Data\File
{
}
