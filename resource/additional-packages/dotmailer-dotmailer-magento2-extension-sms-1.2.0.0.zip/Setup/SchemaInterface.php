<?php

namespace Dotdigitalgroup\Sms\Setup;

interface SchemaInterface
{
    const EMAIL_SMS_ORDER_QUEUE_TABLE = 'email_sms_order_queue';
}
