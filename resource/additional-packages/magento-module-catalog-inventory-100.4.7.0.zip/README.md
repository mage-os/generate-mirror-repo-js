Magento_CatalogInventory module allows retrieve and update stock attributes, such as status and quantity.
