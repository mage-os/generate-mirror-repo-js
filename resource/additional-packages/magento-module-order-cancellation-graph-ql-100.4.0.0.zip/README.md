# Magento_OrderCancellationGraphQl module

The **OrderCancellationGraphQl** module provides a GraphQl endpoint
to cancel an order and specify the order cancellation reason.
