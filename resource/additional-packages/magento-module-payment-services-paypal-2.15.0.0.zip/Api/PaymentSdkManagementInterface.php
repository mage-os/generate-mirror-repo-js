<?php
/**
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2023 Adobe
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe and its suppliers, if any. The intellectual
 * and technical concepts contained herein are proprietary to Adobe
 * and its suppliers and are protected by all applicable intellectual
 * property laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe.
 */

declare(strict_types=1);

namespace Magento\PaymentServicesPaypal\Api;

interface PaymentSdkManagementInterface
{
    /**
     * Get payment sdk params.
     *
     * @param string $location sdk location.
     * @param int|null $store store id.
     * @param string|null $methodCode payment method code.
     * @return array Payment token search result interface.
     * @since 100.1.0
     */
    public function getParams(string $location, ?int $store = null, ?string $methodCode = null): array;
}
