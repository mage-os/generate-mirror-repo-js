# Magento_SaaSCommon module

## Release notes

*Magento_SaaSCommon* module
