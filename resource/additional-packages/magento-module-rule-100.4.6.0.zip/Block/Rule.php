<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Rule\Block;

class Rule extends \Magento\Framework\View\Element\AbstractBlock
{
}
