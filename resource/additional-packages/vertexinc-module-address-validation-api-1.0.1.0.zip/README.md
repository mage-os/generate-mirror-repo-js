# Vertex Address Validation API for Magento 2

This module provides Vertex Address Validation services contracts.

## Extensibility

### Public APIs

Public APIs are defined in the `Api` and `Api\Data` directories.

### REST endpoints

The `etc/webapi.xml` file defines endpoints for cleansing an address.
