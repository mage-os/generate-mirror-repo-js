# Magento_CatalogPageBuilderAnalytics module

The Magento_CatalogPageBuilderAnalytics module configures data definitions for a data collection related to the PageBuilder module entities to be used in [Advanced Reporting](https://developer.adobe.com/commerce/php/development/advanced-reporting/modules/).
