# Magento_RemoteStorage module
