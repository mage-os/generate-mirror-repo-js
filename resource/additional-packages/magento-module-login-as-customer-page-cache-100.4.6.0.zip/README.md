# Magento_LoginAsCustomerPageCache module

This module provides adaptation to PageCache functionality for Login as Customer functionality.

## Additional information

This module is a part of Login As Customer feature.

[Learn more about Login As Customer feature](https://experienceleague.adobe.com/docs/commerce-admin/customers/customer-accounts/manage/login-as-customer.html).
