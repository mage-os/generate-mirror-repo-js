The Magento_PaymentServicesPaypalGraphQl module allows processing payments with Payment Services with GraphQl.
