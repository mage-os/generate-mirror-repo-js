<?php

namespace Dotdigitalgroup\Sms\Model\Queue\OrderItem\Data;

class OrderData
{
    /**
     * @var string
     */
    public $orderStatus;
}
