<?php

namespace Dotdigitalgroup\Sms\Model\Queue\OrderItem\Data;

class CreditMemoData extends OrderData
{
    /**
     * @var string
     */
    public $creditMemoAmount;
}
