var config = {
    map: {
        '*': {
            smsCounter: 'Dotdigitalgroup_Sms/js/counter/sms_counter'
        }
    }
};
