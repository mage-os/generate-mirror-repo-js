<?php

namespace Dotdigitalgroup\Email\Model;

class DateTimeZone extends \DateTimeZone
{
}
