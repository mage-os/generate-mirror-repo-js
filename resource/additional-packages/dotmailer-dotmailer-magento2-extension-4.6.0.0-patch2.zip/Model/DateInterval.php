<?php

namespace Dotdigitalgroup\Email\Model;

class DateInterval extends \DateInterval
{
}
