<?php

namespace Dotdigitalgroup\Email\Controller\Email;

use Dotdigitalgroup\Email\Controller\Edc;

class Coupon extends Edc
{
}
