<?php

namespace Dotdigitalgroup\Email\Controller\Report;

class Recentlyviewed extends \Dotdigitalgroup\Email\Controller\Edc
{
}
