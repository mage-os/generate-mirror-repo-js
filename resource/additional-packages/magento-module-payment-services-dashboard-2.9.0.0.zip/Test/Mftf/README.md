# PaymentServicesDashboard Module Functional Tests

The Functional tests for **Magento_PaymentServicesDashboard** module
