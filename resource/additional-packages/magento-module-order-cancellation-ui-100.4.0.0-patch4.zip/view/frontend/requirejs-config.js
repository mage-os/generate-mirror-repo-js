/**
 * Copyright 2023 Adobe
 * All Rights Reserved.
 */
var config = {
    map: {
        '*': {
            'cancelOrderModal': 'Magento_OrderCancellationUi/js/cancel-order-modal'
        }
    }
};
