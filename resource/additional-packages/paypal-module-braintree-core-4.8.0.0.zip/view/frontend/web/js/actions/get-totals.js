/**
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2025 Adobe
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe and its suppliers, if any. The intellectual
 * and technical concepts contained herein are proprietary to Adobe
 * and its suppliers and are protected by all applicable intellectual
 * property laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe.
 */
define([
    'mage/storage',
    'PayPal_Braintree/js/helper/get-api-url'
], function (storage, getApiUrl) {
  'use strict';

  // TODO: Remove need for storeCode to be passed in.
  return function (storeCode, quoteId) {
      return storage.get(
          getApiUrl("totals", storeCode, quoteId)
      );
  };
});
