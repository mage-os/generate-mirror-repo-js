# Webapi Async Functional Tests

The Functional Test Module for **Magento Webapi Async** module.
