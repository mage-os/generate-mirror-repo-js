The Magento_ServiceProxy provides a customizable way to communicate to a Magento service.
