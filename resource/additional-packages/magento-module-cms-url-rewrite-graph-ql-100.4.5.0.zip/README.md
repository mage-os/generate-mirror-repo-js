# CmsUrlRewriteGraphQl

**CmsUrlRewriteGraphQl** provides type information for the GraphQl module
to generate url rewrite fields for cms information endpoints.
