# Cms Url Rewrite Graph Ql Functional Tests

The Functional Test Module for **Magento Cms Url Rewrite Graph Ql** module.
