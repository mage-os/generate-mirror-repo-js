 This component is designed to provide Bulk Operations Framework.
