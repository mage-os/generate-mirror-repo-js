<?php

namespace Dotdigitalgroup\Email\Logger;

class Logger extends \Monolog\Logger
{
}
