<?php

namespace Dotdigitalgroup\Email\Controller\Product;

class Crosssell extends \Dotdigitalgroup\Email\Controller\Edc
{
}
