<?php

namespace Dotdigitalgroup\Email\Controller\Product;

class Upsell extends \Dotdigitalgroup\Email\Controller\Edc
{
}
