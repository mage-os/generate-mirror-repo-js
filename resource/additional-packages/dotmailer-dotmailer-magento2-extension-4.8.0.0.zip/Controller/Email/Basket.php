<?php

namespace Dotdigitalgroup\Email\Controller\Email;

class Basket extends \Dotdigitalgroup\Email\Controller\Edc
{
}
