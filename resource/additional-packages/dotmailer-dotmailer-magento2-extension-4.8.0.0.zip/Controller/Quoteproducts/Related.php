<?php

namespace Dotdigitalgroup\Email\Controller\Quoteproducts;

class Related extends \Dotdigitalgroup\Email\Controller\Edc
{
}
