# PayPal_BraintreeReward module

The PayPal_BraintreeReward module provides solution to send Reward Points Currency Amount as credit Line Item to the Braintree for the PayPal transactions.
