# PayPal_BraintreeGiftCard module

The PayPal_BraintreeGiftCard module provides solution to display PayPal Express methods on gift card products.
