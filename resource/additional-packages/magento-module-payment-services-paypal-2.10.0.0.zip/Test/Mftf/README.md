# PaymentServicesPaypal Module Functional Tests

The Functional tests for **Magento_PaymentServicesPaypal** module
