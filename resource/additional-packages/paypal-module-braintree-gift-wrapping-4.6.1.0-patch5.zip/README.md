# PayPal_BraintreeGiftWrapping module

The PayPal_BraintreeGiftWrapping module provides solution to send Gift Options for Items, Gift Options for Order and Printed Card as Line Items to the Braintree for the PayPal transactions.
