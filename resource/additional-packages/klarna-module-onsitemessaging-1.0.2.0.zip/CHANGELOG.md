
1.0.2 / 2020-08-10
==================

  * MAGE-2195 Fix issue with empty 'Design theme' field in Klarna On-Site Messaging

1.0.1 / 2020-04-06
==================

  * Initial Release
