<?php
/**
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2023 Adobe
 * All Rights Reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of Adobe and its suppliers, if any. The intellectual
 * and technical concepts contained herein are proprietary to Adobe
 * and its suppliers and are protected by all applicable intellectual
 * property laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe.
 */

declare(strict_types=1);

namespace Magento\PaymentServicesPaypal\Api\Data;

interface PaymentConfigSmartButtonsInterface extends PaymentConfigItemInterface
{
    public const DISPLAY_MESSAGE = 'display_message';
    public const MESSAGE_STYLES = 'message_styles';
    public const BUTTON_STYLES = 'button_styles';
    public const DISPLAY_VENMO = 'display_venmo';
    public const APP_SWITCH_WHEN_AVAILABLE = 'app_switch_when_available';

    /**
     * Get canDisplayMessage
     *
     * @return bool
     */
    public function hasDisplayMessage();

    /**
     * Set canDisplayMessage
     *
     * @param bool $canDisplayMessage
     * @return $this
     */
    public function setHasDisplayMessage($canDisplayMessage);

    /**
     * Get Venmo
     *
     * @return bool
     * @SuppressWarnings(PHPMD.BooleanGetMethodName)
     */
    public function hasDisplayVenmo();

    /**
     * Set Venmo
     *
     * @param bool $canDisplayVenmo
     * @return $this
     */
    public function setHasDisplayVenmo($canDisplayVenmo);

    /**
     * Get messageStyles
     *
     * @return \Magento\PaymentServicesPaypal\Api\Data\PaymentConfigSmartButtonsMessageStylesInterface|null
     */
    public function getMessageStyles();

    /**
     * Set messageStyles
     *
     * @param PaymentConfigSmartButtonsMessageStylesInterface|null $messageStyles
     * @return $this
     */
    public function setMessageStyles($messageStyles);

    /**
     * Get buttonStyles
     *
     * @return \Magento\PaymentServicesPaypal\Api\Data\PaymentConfigButtonStylesInterface
     */
    public function getButtonStyles();

    /**
     * Set buttonStyles
     *
     * @param array $buttonStyles
     * @return $this
     */
    public function setButtonStyles($buttonStyles);

    /**
     * Get appSwitchWhenAvailable
     *
     * @return bool
     * @SuppressWarnings(PHPMD.BooleanGetMethodName)
     */
    public function getAppSwitchWhenAvailable(): bool;

    /**
     * Set appSwitchWhenAvailable
     *
     * @param bool $appSwitchWhenAvailable
     * @return PaymentConfigSmartButtonsInterface
     */
    public function setAppSwitchWhenAvailable(bool $appSwitchWhenAvailable): PaymentConfigSmartButtonsInterface;
}
