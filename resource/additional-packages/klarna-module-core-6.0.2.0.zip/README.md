The Klarna_Core module contains common infrastructure and assets for other Klarna modules. 
