The Magento_SwaggerWebapi module provides the implementation of the REST Webapi module with Magento_Swagger.
