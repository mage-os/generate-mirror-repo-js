Magento_Cookie module allows enabling and configuring HTTP cookie related settings for the store. These settings are available in the store administration.
