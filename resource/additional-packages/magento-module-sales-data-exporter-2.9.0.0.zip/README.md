The Magento_SalesDataExporter provides sales data export.
