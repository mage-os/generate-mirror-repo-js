<?php

namespace PayPal\Braintree\Block\ApplePay;

class Info extends \PayPal\Braintree\Block\Info
{
}
