# Vault Functional Tests

The Functional Test Module for **Magento Vault** module.
