The Magento_InventoryRequisitionList allows the customer to use the new inventory management (MSI).
