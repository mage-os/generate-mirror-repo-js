# GraphQlNewRelic

The _GraphQlNewRelic_ module enables reporting for performance and reliability data of GraphQL using the New Relic service.

## Prerequisites

To take advantage of this module, you must have a New Relic account and install the New Relic extension on your environment
