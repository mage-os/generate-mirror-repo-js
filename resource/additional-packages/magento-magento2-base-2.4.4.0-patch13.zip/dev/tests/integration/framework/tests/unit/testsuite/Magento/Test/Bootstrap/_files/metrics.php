<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

return ['Fixture Label' => ['fixture_key_one', 'fixture_key_two']];
