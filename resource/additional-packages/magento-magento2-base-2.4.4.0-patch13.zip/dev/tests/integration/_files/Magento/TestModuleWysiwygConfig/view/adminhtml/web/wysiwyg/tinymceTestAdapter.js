/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/* eslint-disable strict */
define([
    'mage/adminhtml/wysiwyg/tiny_mce/tinymceAdapter'
], function (tinyMCE) {
    'use strict';

    return tinyMCE;
});
