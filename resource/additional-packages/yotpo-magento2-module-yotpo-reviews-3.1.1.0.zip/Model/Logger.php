<?php
namespace Yotpo\Yotpo\Model;

class Logger extends \Monolog\Logger
{
}
