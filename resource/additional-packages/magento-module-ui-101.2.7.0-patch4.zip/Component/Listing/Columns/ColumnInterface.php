<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponentInterface;

/**
 * @api
 * @since 100.0.2
 */
interface ColumnInterface extends UiComponentInterface
{
    //
}
