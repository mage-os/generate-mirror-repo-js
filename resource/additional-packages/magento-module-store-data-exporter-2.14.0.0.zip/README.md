The Magento_StoreDataExporter provides stores data export.
