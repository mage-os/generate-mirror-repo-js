The Magento_SendFriend implements the functionality behind the "Email to a Friend" link on a product page, which allows to share favorite products with others by clicking the link.
