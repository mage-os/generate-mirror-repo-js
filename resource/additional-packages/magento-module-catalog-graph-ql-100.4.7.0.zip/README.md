# CatalogGraphQl

**CatalogGraphQl** provides type and resolver information for the GraphQl module
to generate catalog and product information endpoints.
