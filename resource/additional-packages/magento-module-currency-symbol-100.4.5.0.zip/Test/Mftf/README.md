# Currency Symbol Functional Tests

The Functional Test Module for **Magento Currency Symbol** module.
