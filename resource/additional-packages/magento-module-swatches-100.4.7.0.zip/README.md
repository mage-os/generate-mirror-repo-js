Magento_Swatches module is replacing default product attributes text values with swatch images, for more convenient product displaying and selection.
