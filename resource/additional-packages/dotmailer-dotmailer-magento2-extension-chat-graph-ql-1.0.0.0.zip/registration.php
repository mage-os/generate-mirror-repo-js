<?php

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Dotdigitalgroup_ChatGraphQl',
    __DIR__
);
