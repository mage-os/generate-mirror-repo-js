<?php

namespace PayPal\Braintree\Block\GooglePay;

class Info extends \PayPal\Braintree\Block\Info
{
}
