<?php
/**
 * Copyright 2022 Adobe
 * All Rights Reserved.
 */
declare(strict_types=1);

return [
    'Magento\Elasticsearch' => [
        'Magento\Elasticsearch8',
        'Magento\OpenSearch'
    ]
];
