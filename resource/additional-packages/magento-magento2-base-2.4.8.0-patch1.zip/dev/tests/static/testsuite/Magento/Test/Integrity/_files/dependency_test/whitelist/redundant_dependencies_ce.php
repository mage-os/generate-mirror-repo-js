<?php
/**
 * Copyright 2025 Adobe
 * All Rights Reserved.
 */
declare(strict_types=1);

return [
    'Magento\Captcha' => [
        'Magento\MagentoZfDb' => 'Magento\MagentoZfDb',
    ]
];
