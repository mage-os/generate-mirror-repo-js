# Magento_LoginAsCustomerFrontendUi module

This module provides UI for Storefront for Login As Customer functionality.

## Additional information

This module is a part of Login As Customer feature.

[Learn more about Login As Customer feature](https://experienceleague.adobe.com/docs/commerce-admin/customers/customer-accounts/manage/login-as-customer.html).
