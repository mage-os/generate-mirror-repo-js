<?php
/**
 * Copyright 2021 Adobe
 * All Rights Reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Magento_QueryXml',
    __DIR__
);
