# PayPal_BraintreeCustomerBalance module

The PayPal_BraintreeCustomerBalance module provides solution to send Store Credit (Customer Balance) as credit Line Item to the Braintree for the PayPal transactions.
