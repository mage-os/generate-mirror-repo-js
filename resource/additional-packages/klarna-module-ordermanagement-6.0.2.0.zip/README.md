The Klarna_Ordermanagement module provides the order management functionality for all Klarna payment methods. This logic includes captures (invoices), refunds, and cancels.
