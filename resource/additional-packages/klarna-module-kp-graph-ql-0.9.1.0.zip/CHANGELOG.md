
0.9.1 / 2020-12-09
==================

  * MAGE-2687 Fix issue with GraphQL variables

0.9.0 / 2020-08-10
==================

  * Initial Release
