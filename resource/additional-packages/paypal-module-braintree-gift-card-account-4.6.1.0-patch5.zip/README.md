# PayPal_BraintreeGiftCardAccount module

The PayPal_BraintreeGiftCardAccount module provides solution to send Gift Cards as credit Line Item to the Braintree for the PayPal transactions.
