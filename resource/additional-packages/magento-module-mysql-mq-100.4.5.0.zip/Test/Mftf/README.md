# Mysql Mq Functional Tests

The Functional Test Module for **Magento Mysql Mq** module.
