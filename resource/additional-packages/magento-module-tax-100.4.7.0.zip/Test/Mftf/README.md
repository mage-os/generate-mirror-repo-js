# Tax Functional Tests

The Functional Test Module for **Magento Tax** module.
