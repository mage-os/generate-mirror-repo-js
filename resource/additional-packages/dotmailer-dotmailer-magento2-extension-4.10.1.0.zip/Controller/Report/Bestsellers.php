<?php

namespace Dotdigitalgroup\Email\Controller\Report;

class Bestsellers extends \Dotdigitalgroup\Email\Controller\Edc
{
}
