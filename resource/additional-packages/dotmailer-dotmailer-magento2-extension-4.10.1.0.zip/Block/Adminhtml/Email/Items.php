<?php

namespace Dotdigitalgroup\Email\Block\Adminhtml\Email;

/**
 * System alert email notification items block.
 *
 * @api
 */
class Items extends \Magento\Framework\View\Element\Template
{
}
