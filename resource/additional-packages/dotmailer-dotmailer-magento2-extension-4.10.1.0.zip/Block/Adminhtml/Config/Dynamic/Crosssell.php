<?php

namespace Dotdigitalgroup\Email\Block\Adminhtml\Config\Dynamic;

class Crosssell extends ReadonlyFormField
{
    use OrderRecommendation;

    const URL_SLUG = 'crosssell';
}
