<?php

namespace Dotdigitalgroup\Email\Block\Adminhtml\Config\Dynamic;

class Related extends ReadonlyFormField
{
    use OrderRecommendation;

    const URL_SLUG = 'related';
}
