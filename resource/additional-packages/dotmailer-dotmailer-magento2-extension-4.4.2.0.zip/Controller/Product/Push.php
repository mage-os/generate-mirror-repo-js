<?php

namespace Dotdigitalgroup\Email\Controller\Product;

class Push extends \Dotdigitalgroup\Email\Controller\Edc
{
}
