<?php

namespace Dotdigitalgroup\Email\Controller\Email;

class Review extends \Dotdigitalgroup\Email\Controller\Edc
{
}
