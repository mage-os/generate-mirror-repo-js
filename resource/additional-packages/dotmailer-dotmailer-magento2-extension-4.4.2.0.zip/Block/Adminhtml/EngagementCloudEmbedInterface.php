<?php

namespace Dotdigitalgroup\Email\Block\Adminhtml;

interface EngagementCloudEmbedInterface
{
    /**
     * @return string
     */
    public function getAction(): string;
}
