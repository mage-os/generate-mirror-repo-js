/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

(function() {
    var env = jasmine.getEnv(),
        config = {random: false};

    env.configure(config);
})();
