<?php
/**
 * Black list for the @see \Magento\Test\Integrity\DependencyTest::testExternalDependencies()
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
return [
    'app/code/Magento/Paypal/Model/AbstractConfig.php' => ['Magento\Cart'],
];
