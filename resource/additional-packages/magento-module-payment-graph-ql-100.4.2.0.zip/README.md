# PaymentGraphQl

**PaymentGraphQl** provides type information for the GraphQl module
to generate payment fields information endpoints.
