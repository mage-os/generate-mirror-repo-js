The PayPal Captcha module provides a possibility to enable Captcha validation on Payflow Pro payment form.
