The Klarna_Onsitemessaging module provides the OnSite Messaging functionality for all Klarna payment methods.
