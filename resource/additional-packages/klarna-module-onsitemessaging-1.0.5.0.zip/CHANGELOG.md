
1.0.4 / 2021-05-12
==================

  * MAGE-3061 Update MFTF credentials path

1.0.3 / 2020-11-24
==================

  * MAGE-2553 Fix Onsite Messaging when used by other Klarna products
  * MAGE-2655 Add MFTF suite and test for Onsite Messaging

1.0.2 / 2020-08-10
==================

  * MAGE-2195 Fix issue with empty 'Design theme' field in Klarna On-Site Messaging

1.0.1 / 2020-04-06
==================

  * Initial Release
