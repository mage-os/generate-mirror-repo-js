# Magento_ServicesId module

The **ServicesId** module is used when Magento needs to communicate with cloud services. 
It provides the necessary identification information about the Magento instance to the service.
