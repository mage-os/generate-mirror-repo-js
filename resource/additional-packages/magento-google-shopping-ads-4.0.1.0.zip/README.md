## Google Shopping ads Channel

Google Shopping ads Channel was disabled on April 28, 2020.

See [End of Life](https://docs.magento.com/m2/ee/user_guide/sales-channels/google-ads/google-eol.html) for more information.
