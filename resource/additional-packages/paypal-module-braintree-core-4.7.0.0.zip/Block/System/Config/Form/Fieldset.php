<?php
/**
 * Copyright 2020 Adobe
 * All Rights Reserved.
 */
declare(strict_types=1);

namespace PayPal\Braintree\Block\System\Config\Form;

use Magento\Paypal\Block\Adminhtml\System\Config\Fieldset\Payment;

class Fieldset extends Payment
{
}
