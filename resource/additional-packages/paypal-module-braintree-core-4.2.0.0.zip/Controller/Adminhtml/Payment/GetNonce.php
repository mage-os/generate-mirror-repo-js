<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace PayPal\Braintree\Controller\Adminhtml\Payment;

class GetNonce extends \PayPal\Braintree\Controller\Payment\GetNonce
{
}
