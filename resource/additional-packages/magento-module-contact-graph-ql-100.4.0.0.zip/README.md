# ContactGraphQlPwa

**ContactGraphQlPwa** provides GraphQL support for `magento/module-contact`.
