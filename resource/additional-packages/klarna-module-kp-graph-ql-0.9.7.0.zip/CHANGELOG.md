
0.9.7 / 2021-09-01
==================

  * MAGE-3343 Fix Klarna payment method discounting (Bump version)

0.9.6 / 2021-08-10
==================

  * MAGE-3314 Retrieve versions without hard dependency

0.9.5 / 2021-08-02
==================

  * MAGE-3157 Add GraphQL usage info to create session api call

0.9.4 / 2021-06-10
==================

  * MAGE-3219 Removed redundant dependencies

0.9.2 / 2021-05-18
==================

  * MAGE-3129 Update di xsi & versions

0.9.1 / 2020-12-09
==================

  * MAGE-2687 Fix issue with GraphQL variables

0.9.0 / 2020-08-10
==================

  * Initial Release
