# CatalogRuleGraphQl

The *Magento_CatalogRuleGraphQl* module applies catalog rules to products for GraphQL requests.
