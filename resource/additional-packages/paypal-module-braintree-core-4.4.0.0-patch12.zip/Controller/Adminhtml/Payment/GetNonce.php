<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace PayPal\Braintree\Controller\Adminhtml\Payment;

use Magento\Framework\App\Action\HttpGetActionInterface;

class GetNonce extends \PayPal\Braintree\Controller\Payment\GetNonce implements HttpGetActionInterface
{
}
