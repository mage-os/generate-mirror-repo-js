<?php
/**
 * Copyright 2024 Adobe
 * All Rights Reserved.
 */
declare(strict_types=1);

namespace Magento\DataExporter\Export;

use Magento\DataExporter\Exception\UnableRetrieveData;
use Magento\DataExporter\Export\Request\InfoAssembler;
use Magento\DataExporter\Model\Indexer\FeedIndexMetadata;
use Magento\DataExporter\Model\Logging\CommerceDataExportLoggerInterface as LoggerInterface;

/**
 * Class Processor
 *
 * Processes data for given field from et_schema
 */
class Processor
{
    /**
     * @var Extractor
     */
    private $extractor;

    /**
     * @var Transformer
     */
    private $transformer;

    /**
     * @var InfoAssembler
     */
    private $infoAssembler;

    /**
     * @var string
     */
    private $rootProfileName;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @param Extractor $extractor
     * @param Transformer $transformer
     * @param InfoAssembler $infoAssembler
     * @param LoggerInterface $logger
     * @param string $rootProfileName
     */
    public function __construct(
        Extractor $extractor,
        Transformer $transformer,
        InfoAssembler $infoAssembler,
        LoggerInterface $logger,
        string $rootProfileName = 'Export'
    ) {
        $this->extractor = $extractor;
        $this->transformer = $transformer;
        $this->infoAssembler = $infoAssembler;
        $this->rootProfileName = $rootProfileName;
        $this->logger = $logger;
    }

    /**
     * Process data inside callback
     *
     * @param FeedIndexMetadata $metadata
     * @param array $arguments
     * @param callable $dataProcessorCallback
     * @param bool $lastChunk
     * @return void
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function processWithCallback(
        FeedIndexMetadata $metadata,
        array $arguments,
        callable $dataProcessorCallback,
        bool $lastChunk = false
    ) : void {
        try {
            $info = $this->infoAssembler->assembleFieldInfo($metadata->getFeedName(), $this->rootProfileName);

            $dataProcessorCallback = function ($snapshots) use ($dataProcessorCallback, $info) {

                $dataProcessorCallback($this->transformer->transform($info, $snapshots));
            };
            $this->extractor->extractWithCallback($info, $arguments, $dataProcessorCallback, $metadata);
        } catch (\Throwable $exception) {
            $provider = empty($info) === false ? $info->getRootNode()->getField()['provider'] : '';
            // if error happened during data collecting we skip entire process
            $this->logger->error(
                \sprintf(
                    'CDE01-05 Unable to sync feed "%s" for ids "%s". Affected data provider: "%s". Error: %s',
                    $metadata->getFeedName(),
                    \implode(', ', array_column($arguments, $metadata->getFeedIdentity())),
                    $provider,
                    $exception->getMessage(),
                ),
                ['exception' => $exception]
            );
            throw new UnableRetrieveData($exception->getMessage());
        }
    }

    /**
     * Process data
     *
     * @param string $fieldName
     * @param array $arguments
     * @param null|array $proxyData - added for backward compatibility with originally `processWithCallback` is called
     * @return array
     */
    public function process(string $fieldName, array $arguments = [], ?array $proxyData = null) : array
    {
        if ($proxyData !== null) {
            return $proxyData;
        }
        try {
            $info = $this->infoAssembler->assembleFieldInfo($fieldName, $this->rootProfileName);
            $snapshots = $this->extractor->extract($info, $arguments);
            return $this->transformer->transform($info, $snapshots);
        } catch (\Throwable $exception) {
            // if error happened during data collecting we skip entire process
            $this->logger->error(
                \sprintf(
                    'CDE01-06 Unable to sync feed "%s" for ids "%s". Error: %s',
                    $fieldName,
                    \var_export($arguments, true),
                    $exception->getMessage(),
                ),
                ['exception' => $exception]
            );
        }

        return [];
    }
}
