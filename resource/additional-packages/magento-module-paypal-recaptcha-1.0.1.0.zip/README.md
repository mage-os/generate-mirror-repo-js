# PayPalReCaptcha

Google reCaptcha integration for Magento2 PayPal PayflowPro payment form

This extension is built on top of MSP ReCaptcha 

See: https://github.com/magento/magespecialist_ReCaptcha