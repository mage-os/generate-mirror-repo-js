<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
?>
<?= 'At the young age of 15, Buffy Summers was chosen to hunt vampires, demons, and the forces of darkness.';
