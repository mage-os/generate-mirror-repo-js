<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
?>
<?= 'A man tells his epic life story: love, betrayal, loneliness, and hunger.';
