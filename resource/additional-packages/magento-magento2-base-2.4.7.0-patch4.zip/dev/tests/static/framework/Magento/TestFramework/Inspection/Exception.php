<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * \Exceptional situation during the static inspection
 */
namespace Magento\TestFramework\Inspection;

class Exception extends \Exception
{
}
