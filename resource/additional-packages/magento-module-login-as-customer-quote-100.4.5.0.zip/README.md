# Magento_LoginAsCustomerQuote module

The Magento_LoginAsCustomerQuote module is responsible for communication between Magento_LoginAsCustomer and shopping cart state.

## Additional information

This module is a part of Login As Customer feature.

[Learn more about Login As Customer feature](https://experienceleague.adobe.com/docs/commerce-admin/customers/customer-accounts/manage/login-as-customer.html).
