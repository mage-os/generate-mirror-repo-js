The Theme module contains common infrastructure that provides an ability to apply and use themes in Magento application.
