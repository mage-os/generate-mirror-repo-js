<?php

namespace Dotdigitalgroup\Email\Controller\Report;

class Mostviewed extends \Dotdigitalgroup\Email\Controller\Edc
{
}
