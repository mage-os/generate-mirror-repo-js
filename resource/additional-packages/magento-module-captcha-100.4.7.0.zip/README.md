The Captcha module allows applying Turing test in the process of user authentication or similar tasks.
