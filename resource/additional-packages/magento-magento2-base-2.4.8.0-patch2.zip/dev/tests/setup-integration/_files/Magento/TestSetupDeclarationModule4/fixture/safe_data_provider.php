<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
return [
    [
        'page_id' => '1',
        'email' => '1@gmail.com',
        'title' => 'Title1'
    ],
    [
        'page_id' => '2',
        'email' => '2@gmail.com',
        'title' => 'Title2'
    ],
    [
        'page_id' => '3',
        'email' => '3@gmail.com',
        'title' => 'Title3'
    ],
    [
        'page_id' => '4',
        'email' => '4@gmail.com',
        'title' => 'Title4'
    ]
];
