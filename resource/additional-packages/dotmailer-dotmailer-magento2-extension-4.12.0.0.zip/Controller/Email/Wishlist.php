<?php

namespace Dotdigitalgroup\Email\Controller\Email;

class Wishlist extends \Dotdigitalgroup\Email\Controller\Edc
{
}
