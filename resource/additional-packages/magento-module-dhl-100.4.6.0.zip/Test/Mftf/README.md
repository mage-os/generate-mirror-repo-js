# Dhl Functional Tests

The Functional Test Module for **Magento Dhl** module.
