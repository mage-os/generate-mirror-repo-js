# Email Functional Tests

The Functional Test Module for **Magento Email** module.
