The Magento_PaymentServicesPaypal module allows processing payments with Payment Services.
