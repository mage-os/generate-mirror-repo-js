<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Sales\Controller\Adminhtml\Order\Invoice;

class Index extends \Magento\Sales\Controller\Adminhtml\Invoice\AbstractInvoice\Index
{
}
