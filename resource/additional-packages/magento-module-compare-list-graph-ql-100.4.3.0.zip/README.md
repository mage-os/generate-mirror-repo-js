# CompareListGraphQl module

The CompareListGraphQl module is designed to implement compare product functionality.
