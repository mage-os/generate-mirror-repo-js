The Magento_PaymentServicesBase module contains configuration settings for Payment Services and client interface needed to communicate with payment services.
