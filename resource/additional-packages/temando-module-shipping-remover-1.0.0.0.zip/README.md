# Magento Shipping Extension

This module clears data after `Temando_Shipping` module and may be safely removed from the system after an upgrade.

## License

For license information, see [LICENSE.txt](LICENSE.txt).
