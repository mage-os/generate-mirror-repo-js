module.exports = {
    'extends': './vendor/magento/magento-coding-standard/eslint/.eslintrc'
};
